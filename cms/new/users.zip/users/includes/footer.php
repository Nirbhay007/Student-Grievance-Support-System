 <footer class="site-footer">
          <div class="text-center">
              <strong>2020@Invincible 6</strong>
              <a href="#" class="go-top">
                  <i class="fa fa-angle-up"></i>
              </a>
          </div>
      </footer>